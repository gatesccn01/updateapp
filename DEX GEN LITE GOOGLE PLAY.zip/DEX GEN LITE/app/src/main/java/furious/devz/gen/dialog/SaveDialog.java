package furious.devz.gen.dialog;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import furious.devz.gen.AESCrypt;
import com.latamsrc.dexgenlite.R;

import furious.devz.gen.AESCryptLatamSRC;
import furious.devz.gen.util.FileUtil;

public class SaveDialog {

    private SharedPreferences sp;

    private String outputString;

    public SaveDialog(final Context c, final JSONObject ja) {


        sp = PreferenceManager.getDefaultSharedPreferences(c);
        AlertDialog.Builder a = new AlertDialog.Builder(c);
        View v = LayoutInflater.from(c).inflate(R.layout.dialog_save, null);

        final EditText e4 = v.findViewById(R.id.fName);

        e4.setText(sp.getString("name", ""));
        final String[] newName = new String[1];

        a.setView(v);
        a.setNeutralButton("CERRAR", null);
        a.setPositiveButton("GUARDAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface p1, int p2) {
                newName[0] = e4.getText().toString();
                sp.edit().putString("name", newName[0]).apply(); // Guardar el nombre en las SharedPreferences

                final String[] b = {e4.getText().toString()};
                final AlertDialog.Builder builder = new AlertDialog.Builder(c);
                builder.setMessage(R.string.tipoencryp);
                builder.setPositiveButton(R.string.sgmlatamsrc, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            String string1 = sp.getString("pass", "");
                            outputString = AESCrypt.encrypt(string1, ja.toString());
                            FileUtil.save(c, b[0], outputString);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Toast.makeText(c, R.string.ifoencrypltamsrc, Toast.LENGTH_LONG).show();
                    }
                });
                builder.setNegativeButton(R.string.dxgplatamsrc, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            String string1 = sp.getString("pass", "");
                            outputString = AESCryptLatamSRC.encrypt(string1, ja.toString());
                            FileUtil.save(c, b[0], outputString);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Toast.makeText(c, R.string.ifoencrypltamsrc, Toast.LENGTH_LONG).show();
                    }
                });
                builder.create().show();
            }
        });


        Dialog dialog = a.create();
        dialog.show();
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.eyesscodes);
    }


}
