package furious.devz.gen;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.github.angads25.filepicker.controller.DialogSelectionListener;
import com.github.angads25.filepicker.model.DialogConfigs;
import com.github.angads25.filepicker.model.DialogProperties;
import com.github.angads25.filepicker.view.FilePickerDialog;
import com.google.android.material.tabs.TabLayout;
import com.latamsrc.dexgenlite.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import cn.pedant.SweetAlert.SweetAlertDialog;
import furious.devz.gen.adapter.ServerSpinnerAdapter;
import furious.devz.gen.dialog.Note;
import furious.devz.gen.dialog.PassDialog;
import furious.devz.gen.dialog.ReleaseNotes;
import furious.devz.gen.dialog.SaveDialog;
import furious.devz.gen.dialog.ServerDialog;
import furious.devz.gen.dialog.Version;
import furious.devz.gen.listener.SpinnerListener;

public class MainActivity extends AppCompatActivity {
    public static final String fdv = "DEX GEN LITE";
    public static final String fdx = "Developed by El Mandarn Sniff :)";
    public static final String app_name = "DEX GEN LITE";
    public static final String pckg = "com.dexgen.lite";
    private static final String[] tabTitle = {"INICIO", "REGISTRO"};
    int SOLIPERMISOSGATESCCN = 200;
    public static TextView fdevz;
    public static ViewPager viewpager;
    private ViewPager vp;
    private TabLayout tabs;
    private SharedPreferences sp;
    private Spinner a, b;
    private AlertDialog about;
    private FilePickerDialog dialog;
    private String v;
    private String n;
    private TabLayout tabLayout;
    private Button buttonedson;
    private Button version;

    private void output() {
        Intent intent = new Intent(Intent.ACTION_DELETE);
        intent.setData(Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    private void password() {
        if (!(((String) getPackageManager().getApplicationLabel(getApplicationInfo())).equals(iProtect.f) && getPackageName().equals(iProtect.t))) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setView(getLayoutInflater().inflate(R.layout.iprotect, null));
            builder.setCancelable(false);
            builder.setNegativeButton("Uninstall", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface p1, int p2) {
                    output();
                }
            });
            builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface p1, int p2) {
                    // TODO: Implement this method
                    if (android.os.Build.VERSION.SDK_INT >= 21) {
                        finishAndRemoveTask();
                    } else {
                        android.os.Process.killProcess(android.os.Process.myPid());
                    }
                    System.exit(0);

                }
            });
            builder.show();

        }
    }


    private void version() {

        if (!(((String) getPackageManager().getApplicationLabel(getApplicationInfo())).equals(MainActivity.app_name) && getPackageName().equals(MainActivity.pckg))) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setView(getLayoutInflater().inflate(R.layout.iprotect, null));
            builder.setCancelable(false);
            builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2) {
                    // TODO: Implement this method
                    if (android.os.Build.VERSION.SDK_INT >= 21) {
                        finishAndRemoveTask();
                    } else {
                        android.os.Process.killProcess(android.os.Process.myPid());
                    }
                    System.exit(0);

                }
            });
            builder.show();

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            vergatesccn();
        }
        password();
        version();
        welcomeNotif();
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setContentView(R.layout.drawermain);
        fdevz = (TextView) findViewById(R.id.ftdev);
        buttonedson = (Button) findViewById(R.id.copy);
        sp = PreferenceManager.getDefaultSharedPreferences(this);
        a = (Spinner) findViewById(R.id.serverList);
        Toolbar m_Toolbar = (Toolbar) findViewById(R.id.toolbar);
        m_Toolbar.setTitle(getString(R.string.app_name));
        doTabs();
        m_Toolbar.setSubtitleTextColor(Color.WHITE);
        setSupportActionBar(m_Toolbar);
        tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        viewpager = (ViewPager) findViewById(R.id.viewpager);
        viewpager.setOffscreenPageLimit(2);
        tabLayout.setupWithViewPager(viewpager);
        tabLayout.setTabMode(TabLayout.MODE_FIXED);
        if (adapter() != null) {
            a.setAdapter(adapter());
        }
        setupJson();
        //SimpleProtect.MyProtect();
        try {
            JSONObject jsonObj = new JSONObject(ja().toString());
            String finalJson = jsonObj.toString(1);

            ((TextView) findViewById(R.id.json)).setText(finalJson);
        } catch (JSONException e) {
        }
        //Runtime External storage permission for saving download files
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_DENIED) {
                Log.d("permission", "permission denied to WRITE_EXTERNAL_STORAGE - requesting it");
                String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissions, 1);
            }
        }
    }

    private void welcomeNotif() {
        NotificationManager notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder notification = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification.setChannelId(this.getPackageName() + ".devz.gen");
            createNotification(notificationManager, this.getPackageName() + ".devz.gen");
        }
        notification.setContentTitle(fdv)
                .setContentText(fdx)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.icono))
                .setDefaults(Notification.DEFAULT_ALL)
                .setPriority(Notification.PRIORITY_HIGH)
                .setShowWhen(true)
                .setSmallIcon(R.drawable.icono);
        notificationManager.notify(4130, notification.getNotification());
    }

    private void createNotification(NotificationManager notificationManager, String id) {
        NotificationChannel mNotif = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mNotif = new NotificationChannel(id, "Developer", NotificationManager.IMPORTANCE_HIGH);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mNotif.setShowBadge(true);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(mNotif);
        }
        // TODO: Implement this method
    }

    public void saveJson1(View v) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_DENIED) {
                Log.d("permission", "permission denied to WRITE_EXTERNAL_STORAGE - requesting it");
                String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissions, 1);
            }
        }
        new SaveDialog((Context) this, this.ja());

    }


    public void saveJson(View v) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_DENIED) {
                Log.d("permission", "permission denied to WRITE_EXTERNAL_STORAGE - requesting it");
                String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissions, 1);
            }
        }
        new SaveDialog((Context) this, this.ja());

    }

    /////ONCLICK PARA EL HOME LATAMSRC///
    /////ONCLICK PARA EL HOME LATAMSRC///    /////ONCLICK PARA EL HOME LATAMSRC///
    /////ONCLICK PARA EL HOME LATAMSRC///
    public void addnotes1(View v) {
        new Note(this, "Gracias Por Tu Preferencia");
    }
    public void agregarversionlatamsrc(View v) {
        new Version(this, "1.0.0");
    }

    public void contraseñalatamsrc(View v) {
        new PassDialog(this, "LatamSRC");
    }

    public void importarconfiguracionlatamsrc(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.tipoencrypimport);
        builder.setPositiveButton(R.string.deseanew, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                importsrmandarin1();
                Toast.makeText(MainActivity.this, "DEX GEN NEW", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton(R.string.deseaold, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                importsrmandarin();
                Toast.makeText(MainActivity.this, "SOCKS GEN OLD", Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void exportarconfiguracionlatamsrc(View v) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_DENIED) {
                Log.d("permission", "permission denied to WRITE_EXTERNAL_STORAGE - requesting it");
                String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissions, 1);
            }
        }
        new SaveDialog((Context) this, this.ja());
    }

    public void borradatoslatamsrc(View v) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Restablecer configuración")
                .setMessage("¿Estás segura de que quieres restablecer?")
                .setPositiveButton("Si", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dia, int which) {
                        sp.edit().clear().apply();
                        recreate();
                    }
                })
                .setNegativeButton("No", null)
                .create();
        dialog.show();
    }
    //GATESCCN
    public void onlinegatesccnupdatejson(View view) {
        View v = LayoutInflater.from(this).inflate(R.layout.importonlinejsongatesccn, null);
        final EditText token = v.findViewById(R.id.code);
        //final EditText pas = v.findViewById(R.id.codepas);
        AlertDialog br = new AlertDialog.Builder(this)
                .setView(v)
                .setPositiveButton("import", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dia, int which) {
                        GATESCNIMPORJSONONLINEVOID(token.getText().toString(), false);

                    }
                })
                .create();
        br.show();
    }




    /////ONCLICK PARA EL HOME LATAMSRC///
    /////ONCLICK PARA EL HOME LATAMSRC///    /////ONCLICK PARA EL HOME LATAMSRC///
    /////ONCLICK PARA EL HOME LATAMSRC///

    public void addnotes(View v) {
        new ReleaseNotes(this, "1.0.0");
    }

    public void editServer(final int position) {

        ServerDialog.Server a = new ServerDialog.Server(MainActivity.this);
        try {
            final JSONArray ja = new JSONArray(sp.getString("ServerList", "[]"));
            a.edit(ja.getJSONObject(position));
            a.onServerAdd(new SpinnerListener() {
                @Override
                public void onAdd(JSONObject json) {
                    try {
                        String[] ob = {"Name", "FLAG", "ServerIP", "sPais", "ServerPort", "SSLPort", "ProxyIP", "ProxyPort", "ServerUser", "ServerPass", "sInfo", "apiCheckUser", "apiOnlineUser", "Payload", "SNI", "Slowchave", "Nameserver", "Slowdns", "isSSL", "isInject", "isPayloadSSL", "isSlow", "isDirect"
                                , "isudp", "udpserver", "udpauth", "udpobfs", "udpdown", "udpup", "udpbuffer", "iv2ray", "v2rayJson", "apilatamsrcv2ray"};
                        for (int i = 0; i < ob.length; i++) {
                            ja.getJSONObject(position).remove(ob[i]);
                        }
                        for (int i = 0; i < json.length(); i++) {
                            ja.getJSONObject(position).put(ob[i], json.getString(ob[i]));
                        }
                        sp.edit().putString("ServerList", ja.toString()).apply();
                        setupJson();

                    } catch (JSONException e) {
                        Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
            a.init();
        } catch (JSONException e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void deleteServer(final int position) {

        try {
            JSONArray ja = new JSONArray(sp.getString("ServerList", "[]"));
            ja.remove(position);
            sp.edit().putString("ServerList", ja.toString()).apply();
            setupJson();

        } catch (JSONException e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }

    }

    public void add(View v) {

        ServerDialog.Server a = new ServerDialog.Server(this);
        a.add();
        a.onServerAdd(new SpinnerListener() {
            @Override
            public void onAdd(JSONObject json) {
                try {
                    JSONArray ja = new JSONArray(sp.getString("ServerList", "[]"));
                    ja.put(json);
                    sp.edit().putString("ServerList", ja.toString()).apply();
                    setupJson();

                } catch (JSONException e) {
                    Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
        a.init();
    }

    public void edit(View v) {
        editServer(a.getSelectedItemPosition());
    }

    public void del(View v) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Eliminar configuración")
                .setMessage("¿Estás segura de que quieres eliminar?")
                .setPositiveButton("Si", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dia, int which) {
                        deleteServer(a.getSelectedItemPosition());
                    }
                })
                .setNegativeButton("No", null)
                .create();
        dialog.show();

    }

    private JSONObject ja() {
        String ja = sp.getString("Configuration", "{}");
        try {

            JSONArray a = new JSONArray(sp.getString("ServerList", "[]"));
            //JSONArray b = new JSONArray(sp.getString("PayloadList", "[]"));
            return new JSONObject(ja).put("Version", this.v).put("ReleaseNotes", this.n).put("Servers", a).put("Networks", b);
        } catch (JSONException e) {
            return null;
        }
    }


    private ServerSpinnerAdapter adapter() {
        ArrayList<JSONObject> al = new ArrayList<JSONObject>();
        ServerSpinnerAdapter ad = new ServerSpinnerAdapter(this, al);
        ad.setPath("servers");
        try {
            for (int i = 0; i < ja().getJSONArray("Servers").length(); i++) {
                JSONArray ja = ja().getJSONArray("Servers");
                al.add(ja.getJSONObject(i));
            }
            return ad;
        } catch (Exception e) {
            return null;
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(1, 1, 1, "About").setIcon(R.drawable.icono).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menu.add(2, 2, 2, "Clear Data").setIcon(R.drawable.borrar).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
//    menu.add(3, 3, 3, "Import").setIcon(R.drawable.import_icon).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
//    menu.add(4, 4, 4, "Password").setIcon(R.drawable.password_icon).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
//    menu.add(5, 5, 5, "Config Version").setIcon(R.drawable.config_version_icon).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
//    menu.add(6, 6, 6, "Save Config").setIcon(R.drawable.save_config_icon).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
            {
                about = new AlertDialog.Builder(this)
                        .setView(getLayoutInflater().inflate(R.layout.prositomandarinsito, null))
                        .setNegativeButton((new String(Base64.decode("ZW50ZW5kaWRv", 0))), null)
                        .setPositiveButton((new String(android.util.Base64.decode("Q29udGFjdGFy", 0))), null)
                        .setCancelable(false)
                        .show();
                about.show();
                Button positiveButton = about.getButton(AlertDialog.BUTTON_POSITIVE);
                positiveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String url1 = ((new String(Base64.decode("Z2F0ZXNjY24=", 0))));
                        Intent intent1 = new Intent(Intent.ACTION_VIEW, Uri.parse(url1));
                        startActivity(Intent.createChooser(intent1, getText(R.string.open_with)));
                        about.dismiss();

                    }
                });
            }
                break;

            case 2:
                AlertDialog dialog = new AlertDialog.Builder(this)
                        .setTitle("Restablecer configuración")
                        .setMessage("¿Estás segura de que quieres restablecer?")
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dia, int which) {
                                sp.edit().clear().apply();
                                recreate();
                            }
                        })
                        .setNegativeButton("No", null)
                        .create();
                dialog.show();
                break;
            case 3:
                setupImport();
                break;
            case 4:
                new PassDialog(this, "LatamSRC");
                break;

            case 5:
                new Version(this, "1.0.0");

                break;

            case 6:
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            == PackageManager.PERMISSION_DENIED) {
                        Log.d("permission", "permission denied to WRITE_EXTERNAL_STORAGE - requesting it");
                        String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        requestPermissions(permissions, 1);
                    }
                }
                new SaveDialog((Context) this, this.ja());


                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupImportDEXGENPRO() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_DENIED) {
                Log.d("permission", "permission denied to WRITE_EXTERNAL_STORAGE - requesting it");
                String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissions, 1);
            }
        }

        DialogProperties properties = new DialogProperties();
        properties.selection_mode = DialogConfigs.SINGLE_MODE;
        properties.selection_type = DialogConfigs.FILE_SELECT;
        properties.extensions = new String[]{".json", ".JSON"};
        properties.root = Environment.getExternalStorageDirectory();
        dialog = new FilePickerDialog(this, properties);
        dialog.setTitle("Busca tu json");
        dialog.setPositiveBtnName("Selecciar");
        dialog.setNegativeBtnName("Cancelar");
        dialog.setDialogSelectionListener(new DialogSelectionListener() {

            @Override
            public void onSelectedFilePaths(final String[] files) {
                for (String path : files) {
                    File file = new File(path);
                    if (file.getName().endsWith(".json") || file.getName().endsWith(".JSON")) {
                        final String data = inet(file.getAbsolutePath());
                        if (TextUtils.isEmpty(data)) {
                            Toast.makeText(getApplicationContext(), "Empty Data!", Toast.LENGTH_LONG).show();


                        } else {

                            //llave para desencryptar
                            try {
                                final JSONObject obj = new JSONObject(AESCryptLatamSRC.decrypt(sp.getString("pass", ""), data));
                                final JSONArray server = obj.getJSONArray("Servers");
                                String version = obj.getString("Version");
                                String notes = obj.getString("ReleaseNotes");
                                sp.edit().putString("ServerList", server.toString()).apply();
                                sp.edit().putString("Version", version).apply();
                                sp.edit().putString("ReleaseNotes", notes).apply();
                                setupJson();

                                Toast.makeText(getApplicationContext(), "Importado Con Exito!", Toast.LENGTH_LONG).show();

                            } catch (JSONException ignored) {

                            } catch (GeneralSecurityException e) {

                                Toast.makeText(getApplicationContext(), "Contraseña MAla!", Toast.LENGTH_LONG).show();
                            }
                            //llave para desencryptar

                        }
                    }
                }
            }
        });

        dialog.show();

    }


    private void setupImport() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_DENIED) {
                Log.d("permission", "permission denied to WRITE_EXTERNAL_STORAGE - requesting it");
                String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissions, 1);
            }
        }

        DialogProperties properties = new DialogProperties();
        properties.selection_mode = DialogConfigs.SINGLE_MODE;
        properties.selection_type = DialogConfigs.FILE_SELECT;
        properties.extensions = new String[]{".json", ".JSON"};
        properties.root = Environment.getExternalStorageDirectory();
        dialog = new FilePickerDialog(this, properties);
        dialog.setTitle("Busca tu json");
        dialog.setPositiveBtnName("Selecciar");
        dialog.setNegativeBtnName("Cancelar");
        dialog.setDialogSelectionListener(new DialogSelectionListener() {

            @Override
            public void onSelectedFilePaths(final String[] files) {
                for (String path : files) {
                    File file = new File(path);
                    if (file.getName().endsWith(".json") || file.getName().endsWith(".JSON")) {
                        final String data = inet(file.getAbsolutePath());
                        if (TextUtils.isEmpty(data)) {
                            Toast.makeText(getApplicationContext(), "Empty Data!", Toast.LENGTH_LONG).show();


                        } else {

                            //sdk 29
                            try {
                                final JSONObject obj = new JSONObject(AESCrypt.decrypt(sp.getString("pass", ""), data));
                                final JSONArray server = obj.getJSONArray("Servers");
                                String version = obj.getString("Version");
                                String notes = obj.getString("ReleaseNotes");
                                sp.edit().putString("ServerList", server.toString()).apply();
                                sp.edit().putString("Version", version).apply();
                                sp.edit().putString("ReleaseNotes", notes).apply();
                                setupJson();

                                Toast.makeText(getApplicationContext(), "Importado Con Exito!", Toast.LENGTH_LONG).show();

                            } catch (JSONException ignored) {

                            } catch (GeneralSecurityException e) {

                                Toast.makeText(getApplicationContext(), "Contraseña MAla!", Toast.LENGTH_LONG).show();
                            }
                            //llave para desencryptar

                        }
                    }
                }
            }
        });

        dialog.show();

    }


    private void setupJson() {
        v = sp.getString("Version", "");
        n = sp.getString("ReleaseNotes", "");
        try {
            JSONObject jsonObj = new JSONObject(ja().toString());
            String finalJson = jsonObj.toString(1);

            ((TextView) findViewById(R.id.json)).setText(finalJson);
        } catch (JSONException e) {
        }

        if (adapter() != null) {
            a.setAdapter(adapter());
        }

    }

    private String inet(String Path) {
        try {
            InputStream openRawResource = new FileInputStream(Path);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            for (int read = openRawResource.read(); read != -1; read = openRawResource.read()) {
                byteArrayOutputStream.write(read);
            }
            openRawResource.close();
            return byteArrayOutputStream.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    @Override
    public void onBackPressed() {
        new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                .setTitleText(getString(R.string.attention))
                .setContentText(getString(R.string.alert_exit))
                .setConfirmText(getString(R.string.exit))
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {

                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                        // TODO: Implement this method
                        finish();

                    }
                })
                .setCancelText(getString(R.string.minimize))
                .showCancelButton(true)
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {

                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                        // TODO: Implement this method
                        Intent startMain = new Intent(Intent.ACTION_MAIN);
                        startMain.addCategory(Intent.CATEGORY_HOME);
                        startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(startMain);
                    }


                })

                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Timer timer2 = new Timer();
        TimerTask qw = new TimerTask() {

            @Override
            public void run() {
                MainActivity mainActivity = MainActivity.this;
                Runnable ja = new Runnable() {
                    @Override
                    public void run() {

                        if (sp.getString("isChanged", "").equals("yes")) {
                            setupJson();
                            sp.edit().putString("isChanged", "no").apply();
                        }
                    }
                };
                mainActivity.runOnUiThread(ja);
            }
        };
        timer2.schedule(qw, (long) 0, (long) 500);
    }

    ///para tab
    public void doTabs() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        try {
            JSONObject jsonObj = new JSONObject(ja().toString());
            String finalJson = jsonObj.toString(1);

            ((TextView) findViewById(R.id.json)).setText(finalJson);
        } catch (JSONException e) {
        }
        vp = (ViewPager) findViewById(R.id.viewpager);
        tabs = (TabLayout) findViewById(R.id.tab_layout);
        vp.setAdapter(new MyAdapter(Arrays.asList(tabTitle)));
        vp.setOffscreenPageLimit(2);
        tabs.setTabMode(TabLayout.MODE_FIXED);
        tabs.setTabGravity(TabLayout.GRAVITY_FILL);
        tabs.setupWithViewPager(vp);

    }

    public class MyAdapter extends PagerAdapter {

        private List<String> titles;

        public MyAdapter(List<String> str) {
            titles = str;
        }

        @Override
        public int getCount() {
            // TODO: Implement this method
            return 2;
        }

        @Override
        public boolean isViewFromObject(View p1, Object p2) {
            // TODO: Implement this method
            return p1 == p2;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            int[] ids = new int[]{R.id.tab1, R.id.tab2};
            int id = 0;
            id = ids[position];
            // TODO: Implement this method
            return findViewById(id);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            // TODO: Implement this method
            return titles.get(position);
        }
    }

    /**
     * Created by: ElMandarinSNiff
     * Date Crated: 10/8/2023
     * Project: LatamSRC (Español)
     **/



    //  EL MANDARIN SNIFF 28/FEB/2024 REGLA PARA IMPORTAR EN LINEA E IMPORTAR SDK 33 ETC ETC
    private void GATESCNIMPORJSONONLINEVOID(final String e, boolean isOnCreate) {
        new git(this, e, new git.OnUpdateListener() {
            @Override
            public void onUpdateListener(String result) {
                try {
                    if (!result.contains("Error on getting data")) {//online
                        final JSONObject obj = new JSONObject(AESCryptLatamSRC.decrypt(sp.getString("pass", ""), result));
                        final JSONArray server = obj.getJSONArray("Servers");
                        String version = obj.getString("Version");
                        String notes = obj.getString("ReleaseNotes");
                        sp.edit().putString("ServerList", server.toString()).apply();
                        sp.edit().putString("Version", version).apply();
                        sp.edit().putString("ReleaseNotes", notes).apply();
                        setupJson();
                        //	Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
                        Toast.makeText(getApplicationContext(), "Imported successfully!", Toast.LENGTH_LONG).show();

                    } else if (result.contains("Error on getting data")) {

                        Toast.makeText(getApplicationContext(), "Error getting data", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Wrong Password", Toast.LENGTH_LONG).show();
                }
            }
        }).start(isOnCreate);
    }
//

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void vergatesccn() {
        int permisosmensajes = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (permisosmensajes == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permiso Otorgado", Toast.LENGTH_SHORT).show();
        } else {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SOLIPERMISOSGATESCCN);
        }
    }

    public void importsrmandarin() {
        permiso();
        if (Build.VERSION.SDK_INT >= 30) {
            Intent importar = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            importar.setType("*/*");
            startActivityForResult(importar, 24);
        } else {
            setupImport();
        }
    }
    ////PARA OTRO ENCRYP BY LATAMSRC
    public void importsrmandarin1() {
        permiso();
        if (Build.VERSION.SDK_INT >= 30) {
            Intent importar = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            importar.setType("*/*");
            startActivityForResult(importar, 25);
        } else {
            setupImportDEXGENPRO();
        }
    }
    ////PARA OTRO ENCRYP BY LATAMSRC
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 24 && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            String contenidoArchivo = null;

            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                String linea;

                while ((linea = reader.readLine()) != null) {
                    stringBuilder.append(linea);
                }

                contenidoArchivo = stringBuilder.toString();
                reader.close();
                inputStream.close();

                importarcontent30(contenidoArchivo);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            if (requestCode == 25 && resultCode == RESULT_OK) {
                Uri uri = data.getData();
                String contenidoArchivo = null;

                try {
                    InputStream inputStream = getContentResolver().openInputStream(uri);
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder stringBuilder = new StringBuilder();
                    String linea;

                    while ((linea = reader.readLine()) != null) {
                        stringBuilder.append(linea);
                    }

                    contenidoArchivo = stringBuilder.toString();
                    reader.close();
                    inputStream.close();

                    importarcontent33(contenidoArchivo);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                }
        }
    }

    private void importarcontent30(String data) { //lol xd
        try {
            final JSONObject obj = new JSONObject(AESCrypt.decrypt(sp.getString("pass", ""), data));
            final JSONArray server = obj.getJSONArray("Servers");
            String version = obj.getString("Version");
            String notes = obj.getString("ReleaseNotes");
            sp.edit().putString("ServerList", server.toString()).apply();
            sp.edit().putString("Version", version).apply();
            sp.edit().putString("ReleaseNotes", notes).apply();
            setupJson();

            Toast.makeText(getApplicationContext(), "IMPORTASTE UNA CONFIG SOCK", Toast.LENGTH_LONG).show();

        } catch (JSONException e) {

        } catch (GeneralSecurityException e) {

            Toast.makeText(getApplicationContext(), "Contra incorrecta o archivo", Toast.LENGTH_LONG).show();
        }
    }
    ////PARA OTRO ENCRYP BY LATAMSRC

    private void importarcontent33(String data) { //lol xd
        try {
            final JSONObject obj = new JSONObject(AESCryptLatamSRC.decrypt(sp.getString("pass", ""), data));
            final JSONArray server = obj.getJSONArray("Servers");
            String version = obj.getString("Version");
            String notes = obj.getString("ReleaseNotes");
            sp.edit().putString("ServerList", server.toString()).apply();
            sp.edit().putString("Version", version).apply();
            sp.edit().putString("ReleaseNotes", notes).apply();
            setupJson();

            Toast.makeText(getApplicationContext(), "IMPORTASTE UNA CONFIG DEX GEN PRO", Toast.LENGTH_LONG).show();

        } catch (JSONException e) {

        } catch (GeneralSecurityException e) {

            Toast.makeText(getApplicationContext(), "Contra incorrecta o archivo", Toast.LENGTH_LONG).show();
        }
    }


    public void permiso() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}, 101);
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode != 101) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        } else if (grantResults.length <= 0 || grantResults[0] != 0) {
//            Toast.makeText(this, "Permiso denegado", Toast.LENGTH_SHORT).show();
//            Toast.makeText(this, "Acepte El Permiso Para Poder Exportar La Configuracion Json", Toast.LENGTH_SHORT).show();
//
        } else {
            Toast.makeText(this, "Permiso aceptado", Toast.LENGTH_SHORT).show();
        }
    }

}
