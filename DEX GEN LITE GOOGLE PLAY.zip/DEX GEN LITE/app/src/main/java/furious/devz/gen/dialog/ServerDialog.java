package furious.devz.gen.dialog;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.latamsrc.dexgenlite.R;

import org.json.JSONObject;

import furious.devz.gen.listener.SpinnerListener;

public class ServerDialog {
    public static class Server {
        private static EditText sauthlatam, sName, sFlag, sHost, sPort, sslPort, rHost, rPort, sinfo, apicheckuser, apionlineuser, user, pass, cPayload, sni, pub, ns, dns;
        private static EditText udpserver, udpauth, udpobfs, udpdown, udpup, udpbuffer, Apiv2;
        private static RadioButton usessl;
        private static RadioButton usessh;
        private static RadioButton usesslpayload;
        private static RadioButton slwd;
        private static RadioButton drc;
        private static RadioButton useudp, useV2rayng;
        private AutoCompleteTextView spaislatamsrc;
        private String[] sugerencias = {"Bolivia", "Chile", "Perú", "Argentina", "Colombia", "Ecuador", "Uruguay", "Paraguay", "Venezuela", "Costa Rica", "Cuba", "República Dominicana", "El Salvador", "México", "Brasil", "Honduras", "Guatemala"};
        private String[] sugerencias1 = {"SSH/SSL", "SSL/PAY", "SLOWDNS", "SSH/PROXY", "DIRECT", "UDP HYSTERIA", "V2RAYNG"};
        private Spinner serverTypeSpinner;
        private AlertDialog.Builder a;
        private Context c;
        private SharedPreferences sp;
        private LinearLayout set_dns, set_pay, set_pro, set_sni;
        private LinearLayout layoutv2raygatesccn, layoutUdp, layouthostgatesccn, layoutsshsslPort, layoutuserpass, laserverauthgatesccn;
        private boolean isSSL;
        private boolean isSSH;
        private boolean iboleanudp;
        private boolean iboleanv2ray;
        private boolean isSSLPayload, slw, drct;

        public Server(Context c) {
            a = new AlertDialog.Builder(c);
            sp = PreferenceManager.getDefaultSharedPreferences(c);
            this.c = c;
        }

        public void add() {
            View v = LayoutInflater.from(c).inflate(R.layout.dialog_add_server, null);
            sName = v.findViewById(R.id.sName);
            spaislatamsrc = v.findViewById(R.id.spaislatamsrc);
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(c, android.R.layout.simple_dropdown_item_1line, sugerencias);
            spaislatamsrc.setAdapter(adapter);
            spaislatamsrc.setThreshold(1);
            sauthlatam = v.findViewById(R.id.sauthlatam);
            sFlag = v.findViewById(R.id.sFlag);
            sHost = v.findViewById(R.id.sHost);
            sPort = v.findViewById(R.id.sPort);
            sslPort = v.findViewById(R.id.sslPort);
            rHost = v.findViewById(R.id.rHost);
            rPort = v.findViewById(R.id.rPort);
            user = v.findViewById(R.id.user);
            pass = v.findViewById(R.id.pass);
            sinfo = v.findViewById(R.id.sInfo);
            apicheckuser = v.findViewById(R.id.apicheckuser);
            apionlineuser = v.findViewById(R.id.apionlineuser);
            usesslpayload = v.findViewById(R.id.useWSpayload);
            usessl = v.findViewById(R.id.useSSL);
            usessh = v.findViewById(R.id.useInject);
            cPayload = v.findViewById(R.id.cPayload);
            sni = v.findViewById(R.id.sni);
            slwd = v.findViewById(R.id.mahina);
            drc = v.findViewById(R.id.useDirect);
            pub = v.findViewById(R.id.pubkey);
            ns = v.findViewById(R.id.ns);
            dns = v.findViewById(R.id.dns);
            udpbuffer = v.findViewById(R.id.udpbuffer);
            Apiv2 = v.findViewById(R.id.Apiv2);
            udpauth = v.findViewById(R.id.udpauth);
            udpdown = v.findViewById(R.id.udpdown);
            udpobfs = v.findViewById(R.id.udpobfs);
            udpup = v.findViewById(R.id.udpup);
            udpserver = v.findViewById(R.id.udpserver);
            useudp = v.findViewById(R.id.useUDP);
            useV2rayng = v.findViewById(R.id.useV2rayng);
            set_dns = v.findViewById(R.id.slowsettings);
            set_pay = v.findViewById(R.id.spy);
            set_pro = v.findViewById(R.id.spro);
            set_sni = v.findViewById(R.id.sni2);
            /*PARA VIEW DEL NUEVO GEN*/
            layoutv2raygatesccn = v.findViewById(R.id.layoutv2raygatesccn);
            layoutUdp = v.findViewById(R.id.layoutUdp);


            layouthostgatesccn = v.findViewById(R.id.layouthostgatesccn);
            layoutsshsslPort = v.findViewById(R.id.layoutsshsslPort);
            layoutuserpass = v.findViewById(R.id.layoutuserpass);
            laserverauthgatesccn = v.findViewById(R.id.laserverauthgatesccn);

            /*BY LATAMSRC SNER 2024*/
            /*PARA VIEW DEL NUEVO GEN*/
            serverTypeSpinner = v.findViewById(R.id.serverType);
            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(c, android.R.layout.simple_spinner_item, sugerencias1);
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            serverTypeSpinner.setAdapter(spinnerAdapter);
            /*BY LATAMSRC SNER 2024*/
            //			Condicionales que determinan que se mostrará en el Spinner
            serverTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                    // Obtiene la opción seleccionada del Spinner
                    String selectedOption = (String) parentView.getItemAtPosition(position);
                    // Aquí puedes mostrar u ocultar elementos basados en la opción seleccionada
                    if ("SSH/SSL".equals(selectedOption)) {
                        usessl.setChecked(true);
                        usesslpayload.setChecked(false);
                        usessh.setChecked(false);
                        slwd.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);

                    } else if ("SSL/PAY".equals(selectedOption)) {
                        usesslpayload.setChecked(true);
                        usessl.setChecked(false);
                        usessh.setChecked(false);
                        slwd.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);

                    } else if ("SLOWDNS".equals(selectedOption)) {
                        slwd.setChecked(true);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        usessh.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);
                    } else if ("SSH/PROXY".equals(selectedOption)) {
                        usessh.setChecked(true);
                        slwd.setChecked(false);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);
                    } else if ("DIRECT".equals(selectedOption)) {
                        drc.setChecked(true);
                        usessh.setChecked(false);
                        slwd.setChecked(false);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);
                    } else if ("UDP HYSTERIA".equals(selectedOption)) {
                        useudp.setChecked(true);
                        drc.setChecked(false);
                        usessh.setChecked(false);
                        slwd.setChecked(false);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        useV2rayng.setChecked(false);
                    } else if ("V2RAYNG".equals(selectedOption)) {
                        useV2rayng.setChecked(true);
                        drc.setChecked(false);
                        usessh.setChecked(false);
                        slwd.setChecked(false);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        useudp.setChecked(false);

                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parentView) {
                    // Aquí puedes manejar el caso en que no se selecciona nada
                }
            });
            /*PARA VIEW DEL NUEVO GEN*/

            /*PARA VIEW DEL NUEVO GEN*/
            /*PARA VIEW DEL NUEVO GEN*/

            usessl.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.GONE);
                        set_dns.setVisibility(View.GONE);
                        set_pay.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);
                        layoutuserpass.setVisibility(View.VISIBLE);

                        layouthostgatesccn.setVisibility(View.VISIBLE);
                        layoutsshsslPort.setVisibility(View.VISIBLE);

                        layoutUdp.setVisibility(View.GONE);
                        set_sni.setVisibility(View.VISIBLE);
                        usessh.setChecked(false);
                        usesslpayload.setChecked(false);
                        slwd.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);

                    }
                }
            });
            usesslpayload.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.VISIBLE);
                        set_dns.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);
                        layouthostgatesccn.setVisibility(View.VISIBLE);
                        layoutsshsslPort.setVisibility(View.VISIBLE);
                        layoutUdp.setVisibility(View.GONE);
                        set_pay.setVisibility(View.VISIBLE);
                        set_sni.setVisibility(View.VISIBLE);
                        usessh.setChecked(false);
                        usessl.setChecked(false);
                        slwd.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);
                        layoutuserpass.setVisibility(View.VISIBLE);


                    }
                }
            });
            slwd.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        layoutUdp.setVisibility(View.GONE);
                        set_dns.setVisibility(View.VISIBLE);
                        set_pay.setVisibility(View.GONE);
                        set_sni.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);

                        //by latam beta

                        layouthostgatesccn.setVisibility(View.VISIBLE);
                        layoutsshsslPort.setVisibility(View.GONE);
                        layoutuserpass.setVisibility(View.VISIBLE);
                        //by latam beta
                        usessh.setChecked(false);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);


                    }
                }
            });
            usessh.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.VISIBLE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        layoutUdp.setVisibility(View.GONE);
                        set_dns.setVisibility(View.GONE);
                        set_pay.setVisibility(View.VISIBLE);
                        set_sni.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);

                        //by latam beta

                        layouthostgatesccn.setVisibility(View.VISIBLE);
                        layoutsshsslPort.setVisibility(View.VISIBLE);
                        layoutuserpass.setVisibility(View.VISIBLE);
                        //by latam beta
                        usessl.setChecked(false);
                        usesslpayload.setChecked(false);
                        slwd.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);


                    }
                }
            });

            drc.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.VISIBLE);
                        set_dns.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        layoutUdp.setVisibility(View.GONE);
                        set_pay.setVisibility(View.VISIBLE);
                        set_sni.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);

                        //by latam beta

                        layouthostgatesccn.setVisibility(View.VISIBLE);
                        layoutsshsslPort.setVisibility(View.VISIBLE);
                        layoutuserpass.setVisibility(View.VISIBLE);
                        //by latam beta
                        usessh.setChecked(false);
                        usesslpayload.setChecked(false);
                        slwd.setChecked(false);
                        usessl.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);


                    }
                }
            });
            //gatesccn**/
            useudp.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        udpdown.setText("15");
                        udpup.setText("75");
                        udpbuffer.setText("8888");
                        set_pro.setVisibility(View.GONE);
                        set_dns.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        layoutUdp.setVisibility(View.VISIBLE);
                        set_pay.setVisibility(View.GONE);
                        set_sni.setVisibility(View.GONE);
                        //////laservergatesccn.setVisibility(View.GONE);
                        layouthostgatesccn.setVisibility(View.GONE);
                        layoutsshsslPort.setVisibility(View.GONE);
                        layoutuserpass.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);

                        usessh.setChecked(false);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        drc.setChecked(false);
                        slwd.setChecked(false);
                        useV2rayng.setChecked(false);

                    }
                }
            });
//gatesccn**/
            useV2rayng.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.VISIBLE);
                        layoutUdp.setVisibility(View.GONE);
                        set_dns.setVisibility(View.GONE);
                        set_pay.setVisibility(View.GONE);
                        set_sni.setVisibility(View.GONE);


                        //////laservergatesccn.setVisibility(View.GONE);
                        layouthostgatesccn.setVisibility(View.GONE);
                        layoutsshsslPort.setVisibility(View.GONE);
                        layoutuserpass.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.VISIBLE);
                        usessh.setChecked(false);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        drc.setChecked(false);
                        slwd.setChecked(false);
                        useudp.setChecked(false);

                    }
                }
            });


            a.setView(v);
        }

        public void edit(JSONObject json) {
            View v = LayoutInflater.from(c).inflate(R.layout.editarserverlatamsrc, null);
            sName = v.findViewById(R.id.sName);
            sauthlatam = v.findViewById(R.id.sauthlatam);
            spaislatamsrc = v.findViewById(R.id.spaislatamsrc);
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(c, android.R.layout.simple_dropdown_item_1line, sugerencias);
            spaislatamsrc.setAdapter(adapter);
            spaislatamsrc.setThreshold(1);
            sFlag = v.findViewById(R.id.sFlag);
            sHost = v.findViewById(R.id.sHost);
            sPort = v.findViewById(R.id.sPort);
            sslPort = v.findViewById(R.id.sslPort);
            rHost = v.findViewById(R.id.rHost);
            rPort = v.findViewById(R.id.rPort);
            user = v.findViewById(R.id.user);
            pass = v.findViewById(R.id.pass);
            sinfo = v.findViewById(R.id.sInfo);
            apicheckuser = v.findViewById(R.id.apicheckuser);
            apionlineuser = v.findViewById(R.id.apionlineuser);
            usesslpayload = v.findViewById(R.id.useWSpayload);
            usessl = v.findViewById(R.id.useSSL);
            usessh = v.findViewById(R.id.useInject);
            cPayload = v.findViewById(R.id.cPayload);
            sni = v.findViewById(R.id.sni);
            slwd = v.findViewById(R.id.mahina);
            drc = v.findViewById(R.id.useDirect);
            pub = v.findViewById(R.id.pubkey);
            ns = v.findViewById(R.id.ns);
            dns = v.findViewById(R.id.dns);
            udpbuffer = v.findViewById(R.id.udpbuffer);
            Apiv2 = v.findViewById(R.id.Apiv2);
            udpauth = v.findViewById(R.id.udpauth);
            udpdown = v.findViewById(R.id.udpdown);
            udpobfs = v.findViewById(R.id.udpobfs);
            udpup = v.findViewById(R.id.udpup);
            udpserver = v.findViewById(R.id.udpserver);
            useudp = v.findViewById(R.id.useUDP);
            useV2rayng = v.findViewById(R.id.useV2rayng);
            set_dns = v.findViewById(R.id.slowsettings);
            set_pay = v.findViewById(R.id.spy);
            set_pro = v.findViewById(R.id.spro);
            set_sni = v.findViewById(R.id.sni2);
            /*PARA VIEW DEL NUEVO GEN*/
            layoutv2raygatesccn = v.findViewById(R.id.layoutv2raygatesccn);
            layoutUdp = v.findViewById(R.id.layoutUdp);

            layouthostgatesccn = v.findViewById(R.id.layouthostgatesccn);
            layoutsshsslPort = v.findViewById(R.id.layoutsshsslPort);
            layoutuserpass = v.findViewById(R.id.layoutuserpass);
            laserverauthgatesccn = v.findViewById(R.id.laserverauthgatesccn);


            /*PARA VIEW DEL NUEVO GEN*/

            /*PARA VIEW DEL NUEVO GEN*/
            /*PARA VIEW DEL NUEVO GEN*/

            usessl.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.GONE);
                        set_dns.setVisibility(View.GONE);
                        set_pay.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);
                        layoutuserpass.setVisibility(View.VISIBLE);

                        layouthostgatesccn.setVisibility(View.VISIBLE);
                        layoutsshsslPort.setVisibility(View.VISIBLE);

                        layoutUdp.setVisibility(View.GONE);
                        set_sni.setVisibility(View.VISIBLE);
                        usessh.setChecked(false);
                        usesslpayload.setChecked(false);
                        slwd.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);

                    }
                }
            });
            usesslpayload.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.VISIBLE);
                        set_dns.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);
                        layouthostgatesccn.setVisibility(View.VISIBLE);
                        layoutsshsslPort.setVisibility(View.VISIBLE);
                        layoutUdp.setVisibility(View.GONE);
                        set_pay.setVisibility(View.VISIBLE);
                        set_sni.setVisibility(View.VISIBLE);
                        usessh.setChecked(false);
                        usessl.setChecked(false);
                        slwd.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);
                        layoutuserpass.setVisibility(View.VISIBLE);


                    }
                }
            });
            slwd.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        layoutUdp.setVisibility(View.GONE);
                        set_dns.setVisibility(View.VISIBLE);
                        set_pay.setVisibility(View.GONE);
                        set_sni.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);

                        //by latam beta

                        layouthostgatesccn.setVisibility(View.VISIBLE);
                        layoutsshsslPort.setVisibility(View.GONE);
                        layoutuserpass.setVisibility(View.VISIBLE);
                        //by latam beta
                        usessh.setChecked(false);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);


                    }
                }
            });
            usessh.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.VISIBLE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        layoutUdp.setVisibility(View.GONE);
                        set_dns.setVisibility(View.GONE);
                        set_pay.setVisibility(View.VISIBLE);
                        set_sni.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);

                        //by latam beta

                        layouthostgatesccn.setVisibility(View.VISIBLE);
                        layoutsshsslPort.setVisibility(View.VISIBLE);
                        layoutuserpass.setVisibility(View.VISIBLE);
                        //by latam beta
                        usessl.setChecked(false);
                        usesslpayload.setChecked(false);
                        slwd.setChecked(false);
                        drc.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);


                    }
                }
            });

            drc.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.VISIBLE);
                        set_dns.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        layoutUdp.setVisibility(View.GONE);
                        set_pay.setVisibility(View.VISIBLE);
                        set_sni.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);

                        //by latam beta

                        layouthostgatesccn.setVisibility(View.VISIBLE);
                        layoutsshsslPort.setVisibility(View.VISIBLE);
                        layoutuserpass.setVisibility(View.VISIBLE);
                        //by latam beta
                        usessh.setChecked(false);
                        usesslpayload.setChecked(false);
                        slwd.setChecked(false);
                        usessl.setChecked(false);
                        useudp.setChecked(false);
                        useV2rayng.setChecked(false);


                    }
                }
            });
            //gatesccn**/
            useudp.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        udpdown.setText("15");
                        udpup.setText("75");
                        udpbuffer.setText("8888");
                        set_pro.setVisibility(View.GONE);
                        set_dns.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.GONE);
                        layoutUdp.setVisibility(View.VISIBLE);
                        set_pay.setVisibility(View.GONE);
                        set_sni.setVisibility(View.GONE);
                        //////laservergatesccn.setVisibility(View.GONE);
                        layouthostgatesccn.setVisibility(View.GONE);
                        layoutsshsslPort.setVisibility(View.GONE);
                        layoutuserpass.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.GONE);

                        usessh.setChecked(false);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        drc.setChecked(false);
                        slwd.setChecked(false);
                        useV2rayng.setChecked(false);

                    }
                }
            });
//gatesccn**/
            useV2rayng.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if (p2) {
                        set_pro.setVisibility(View.GONE);
                        layoutv2raygatesccn.setVisibility(View.VISIBLE);
                        layoutUdp.setVisibility(View.GONE);
                        set_dns.setVisibility(View.GONE);
                        set_pay.setVisibility(View.GONE);
                        set_sni.setVisibility(View.GONE);


                        //////laservergatesccn.setVisibility(View.GONE);
                        layouthostgatesccn.setVisibility(View.GONE);
                        layoutsshsslPort.setVisibility(View.GONE);
                        layoutuserpass.setVisibility(View.GONE);
                        laserverauthgatesccn.setVisibility(View.VISIBLE);
                        usessh.setChecked(false);
                        usesslpayload.setChecked(false);
                        usessl.setChecked(false);
                        drc.setChecked(false);
                        slwd.setChecked(false);
                        useudp.setChecked(false);

                    }
                }
            });


            try {
                sName.setText(json.getString("Name"));
                sauthlatam.setText(json.getString("apilatamsrcv2ray"));
                spaislatamsrc.setText(json.getString("sPais"));
                sFlag.setText(json.getString("FLAG"));
                sHost.setText(json.getString("ServerIP"));
                sPort.setText(json.getString("ServerPort"));
                sslPort.setText(json.getString("SSLPort"));
                rHost.setText(json.getString("ProxyIP"));
                rPort.setText(json.getString("ProxyPort"));
                user.setText(json.getString("ServerUser"));
                pass.setText(json.getString("ServerPass"));
                sinfo.setText(json.getString("sInfo"));
                apicheckuser.setText(json.getString("apiCheckUser"));
                apionlineuser.setText(json.getString("apiOnlineUser"));

                cPayload.setText(json.getString("Payload"));
                sni.setText(json.getString("SNI"));
                pub.setText(json.getString("Slowchave"));
                ns.setText(json.getString("Nameserver"));
                dns.setText(json.getString("Slowdns"));
                udpauth.setText(json.getString("udpauth"));
                udpbuffer.setText(json.getString("udpbuffer"));
                Apiv2.setText(json.getString("v2rayJson"));
                udpdown.setText(json.getString("udpdown"));
                udpobfs.setText(json.getString("udpobfs"));
                udpup.setText(json.getString("udpup"));
                udpserver.setText(json.getString("udpserver"));
                usessl.setChecked(json.getBoolean("isSSL"));
                usessh.setChecked(json.getBoolean("isInject"));
                usesslpayload.setChecked(json.getBoolean("isPayloadSSL"));
                useudp.setChecked(json.getBoolean("isudp"));
                useV2rayng.setChecked(json.getBoolean("iv2ray"));
                drc.setChecked(json.getBoolean("isDirect"));
                slwd.setChecked(json.getBoolean("isSlow"));


            } catch (Exception e) {
            }
            a.setView(v);
        }

        public void onServerAdd(final SpinnerListener oca) {
            a.setNegativeButton(R.string.CERRAR, null);
            a.setPositiveButton(R.string.GUARDAR, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface p1, int p2) {
                    JSONObject jo = new JSONObject();

                    try {
                        jo.put("Name", sName.getText().toString());
                        jo.put("apilatamsrcv2ray", sauthlatam.getText().toString());
                        jo.put("sPais", spaislatamsrc.getText().toString());

                        jo.put("FLAG", sFlag.getText().toString());
                        jo.put("ServerIP", sHost.getText().toString());

                        jo.put("ServerPort", sPort.getText().toString());
                        jo.put("SSLPort", sslPort.getText().toString());
                        jo.put("ProxyIP", rHost.getText().toString());
                        jo.put("ProxyPort", rPort.getText().toString());
                        jo.put("ServerUser", user.getText().toString());
                        jo.put("ServerPass", pass.getText().toString());
                        jo.put("sInfo", sinfo.getText().toString());
                        jo.put("apiCheckUser", apicheckuser.getText().toString());
                        jo.put("apiOnlineUser", apionlineuser.getText().toString());

                        jo.put("Payload", cPayload.getText().toString());
                        jo.put("SNI", sni.getText().toString());
                        jo.put("Slowchave", pub.getText().toString());
                        jo.put("Nameserver", ns.getText().toString());
                        jo.put("Slowdns", dns.getText().toString());
                        jo.put("udpserver", udpserver.getText().toString());
                        jo.put("udpauth", udpauth.getText().toString());
                        jo.put("udpdown", udpdown.getText().toString());
                        jo.put("udpbuffer", udpbuffer.getText().toString());
                        jo.put("v2rayJson", Apiv2.getText().toString());

                        jo.put("udpobfs", udpobfs.getText().toString());
                        jo.put("udpup", udpup.getText().toString());


                        if (usessl.isChecked()) {
                            isSSL = true;
                            isSSLPayload = false;
                            slw = false;
                            isSSH = false;
                            drct = false;
                            iboleanudp = false;
                            iboleanv2ray = false;

                            jo.put("isSSL", isSSL);
                        } else {
                            isSSL = false;
                            jo.put("isSSL", isSSL);
                        }
                        if (usesslpayload.isChecked()) {
                            isSSL = false;
                            isSSLPayload = true;
                            slw = false;
                            isSSH = false;
                            drct = false;
                            iboleanudp = false;
                            iboleanv2ray = false;


                            jo.put("isPayloadSSL", isSSLPayload);
                        } else {
                            isSSLPayload = false;
                            jo.put("isPayloadSSL", isSSLPayload);
                        }
                        if (slwd.isChecked()) {
                            isSSL = false;
                            isSSLPayload = false;
                            slw = true;
                            isSSH = false;
                            drct = false;
                            iboleanudp = false;
                            iboleanv2ray = false;


                            jo.put("isSlow", slw);
                        } else {
                            slw = false;
                            jo.put("isSlow", slw);
                        }
                        if (usessh.isChecked()) {
                            isSSL = false;
                            isSSLPayload = false;
                            slw = false;
                            isSSH = true;
                            drct = false;
                            iboleanudp = false;
                            iboleanv2ray = false;


                            jo.put("isInject", isSSH);
                        } else {
                            isSSH = false;
                            jo.put("isInject", isSSH);
                        }

                        if (drc.isChecked()) {
                            isSSL = false;
                            isSSLPayload = false;
                            slw = false;
                            isSSH = false;
                            drct = true;
                            iboleanudp = false;
                            iboleanv2ray = false;


                            jo.put("isDirect", drct);
                        } else {
                            drct = false;
                            jo.put("isDirect", drct);
                        }

                        /*adicionar aqui el otro pro*/
                        /*adicionar aqui el otro pro*/
                        /*adicionar aqui el otro pro*/
                        /*adicionar aqui el otro pro*/


                        if (useudp.isChecked()) {
                            isSSL = false;
                            isSSLPayload = false;
                            slw = false;
                            isSSH = false;
                            drct = false;
                            iboleanudp = true;
                            iboleanv2ray = false;

                            jo.put("isudp", iboleanudp);
                        } else {
                            iboleanudp = false;
                            jo.put("isudp", iboleanudp);
                        }


                        if (useV2rayng.isChecked()) {
                            isSSL = false;
                            isSSLPayload = false;
                            slw = false;
                            isSSH = false;
                            drct = false;
                            iboleanudp = false;
                            iboleanv2ray = true;
                            jo.put("iv2ray", iboleanv2ray);
                        } else {
                            iboleanv2ray = false;
                            jo.put("iv2ray", iboleanv2ray);
                        }

                        /*adicionar aqui el otro pro*/
                        /*adicionar aqui el otro pro*/
                        /*adicionar aqui el otro pro*/


                        sp.edit().putString("Name", sName.getText().toString()).apply();
                        sp.edit().putString("apilatamsrcv2ray", sauthlatam.getText().toString()).apply();
                        sp.edit().putString("sPais", spaislatamsrc.getText().toString()).apply();
                        sp.edit().putString("FLAG", sFlag.getText().toString()).apply();
                        sp.edit().putString("ServerIP", sHost.getText().toString()).apply();
                        sp.edit().putString("ServerPort", sPort.getText().toString()).apply();
                        sp.edit().putString("SSLPort", sslPort.getText().toString()).apply();
                        sp.edit().putString("ProxyIP", rHost.getText().toString()).apply();
                        sp.edit().putString("ProxyPort", rPort.getText().toString()).apply();
                        sp.edit().putString("ServerUser", user.getText().toString()).apply();
                        sp.edit().putString("ServerPass", pass.getText().toString()).apply();
                        sp.edit().putString("sInfo", sinfo.getText().toString()).apply();
                        sp.edit().putString("apiCheckUser", apicheckuser.getText().toString()).apply();
                        sp.edit().putString("apiOnlineUser", apionlineuser.getText().toString()).apply();


                        sp.edit().putString("Payload", cPayload.getText().toString()).apply();
                        sp.edit().putString("SNI", sni.getText().toString()).apply();
                        sp.edit().putString("Slowchave", pub.getText().toString()).apply();
                        sp.edit().putString("Nameserver", ns.getText().toString()).apply();
                        sp.edit().putString("Slowdns", dns.getText().toString()).apply();
                        sp.edit().putString("v2rayJson", Apiv2.getText().toString()).apply();

                        sp.edit().putBoolean("isSSL", isSSL).apply();
                        sp.edit().putBoolean("isInject", isSSH).apply();
                        sp.edit().putBoolean("isPayloadSSL", isSSLPayload).apply();
                        sp.edit().putBoolean("isSlow", slw).apply();
                        sp.edit().putBoolean("isDirect", drct).apply();

                        sp.edit().putBoolean("isudp", iboleanudp).apply();
                        sp.edit().putBoolean("iv2ray", iboleanv2ray).apply();

                        oca.onAdd(jo);
                        Toast.makeText(c, "AGREGADO A LA LISTA", Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Toast.makeText(c, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        public void init() {
            a.create().show();
        }
    }
}




