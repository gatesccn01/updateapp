package furious.devz.gen;


public class iProtect {


    public static final String f = "DEX GEN LITE";
    public static final String t = "com.dexgen.lite";

}
   
	
