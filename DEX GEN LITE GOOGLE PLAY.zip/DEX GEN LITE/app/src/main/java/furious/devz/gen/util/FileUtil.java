package furious.devz.gen.util;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class FileUtil {
    private static File dir;
    public static void save(Context c,String title,String content)
    {
        if (Build.VERSION.SDK_INT >= 30) {
            dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "LITE DEX GEN");
        } else {
            dir = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/LITE DEX GEN");
        }
        dir.mkdirs();
        File file=new File(dir,title+".json");
        try
        {
            OutputStream os=new FileOutputStream(file);
            os.write(content.getBytes());
            os.flush();
            os.close();
            //    Toast.makeText(c,"Save Successfuly!",1).show();

        }
        catch (IOException e)
        {
            Toast.makeText(c,e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
