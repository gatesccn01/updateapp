package furious.devz.gen;


import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


/**
 * Created by: gatesccn
 * Date Crated: 08/10/2024
 * Project: SocksHttp-master (ENGLISH)
 **/
public class git extends AsyncTask<String, String, String> {

    private Context context;
    private OnUpdateListener listener;
    private boolean isOnCreate;

    private ProgressDialog progressDialog;

    private String s;

    public git(Context context, String s, OnUpdateListener listener) {
        this.context = context;
        this.listener = listener;
        this.s = s;
    }

    public void start(boolean isOnCreate) {
        this.isOnCreate = isOnCreate;
        execute();
    }

    public interface OnUpdateListener {
        void onUpdateListener(String result);
    }

    @Override
    protected String doInBackground(String... strings) {
        try {
            StringBuilder sb = new StringBuilder();
            URL url = new URL(s);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String response;

            while ((response = br.readLine()) != null) {
                sb.append(response);
            }
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "Error on getting data: " + e.getMessage();
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        if (!isOnCreate) {
            progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Finding Config...");
            progressDialog.setTitle("Please wait...");
            progressDialog.setCancelable(true);
            progressDialog.show();
        }
    }


    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        if (progressDialog != null && !isOnCreate) {
            progressDialog.dismiss();

        }
        if (listener != null) {
            listener.onUpdateListener(s);
        }
    }
}
